import os
import sys
import numpy as np
import logging

# Set TensorFlow logging level to error to suppress warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # TensorFlow
logging.getLogger('tensorflow').setLevel(logging.ERROR)  # TensorFlow
logging.getLogger('tensorflow').disabled = True  # TensorFlow

os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'  # Additional warning suppression

from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from flask import Flask, request, render_template
from werkzeug.utils import secure_filename

# Define a Flask app
app = Flask(__name__)

# Model paths
MODEL_RESNET_PATH = 'model_resnet50.h5'
MODEL_VGG_PATH = 'model_vgg16.h5'
MODEL_CNN_PATH = 'model_cnn.h5'

# Load your trained models
model_resnet = load_model(MODEL_RESNET_PATH)
model_vgg = load_model(MODEL_VGG_PATH)
model_cnn = load_model(MODEL_CNN_PATH)

# Compile models to suppress the warnings related to model compilation
model_resnet.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model_vgg.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model_cnn.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

print('Models loaded. Check http://127.0.0.1:5000/')

def model_predict(img_path, model):
    img = image.load_img(img_path, target_size=(64, 64))  # Adjust target_size to match the model input size

    # Preprocessing the image
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = x / 255.0  # Rescale the image the same way as during training

    preds = model.predict(x)
    return preds

@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
@app.route('/predict', methods=['POST'])
def upload():
    try:
        if request.method == 'POST':
            # Get the file from post request
            f = request.files['file']
            if f:
                # Save the file to ./uploads
                basepath = os.path.dirname(__file__)
                upload_path = os.path.join(basepath, 'uploads')
                os.makedirs(upload_path, exist_ok=True)
                file_path = os.path.join(upload_path, secure_filename(f.filename))
                f.save(file_path)

                # Make predictions with all models
                preds_resnet = model_predict(file_path, model_resnet)
                preds_vgg = model_predict(file_path, model_vgg)
                preds_cnn = model_predict(file_path, model_cnn)

                # Process results for human
                pred_class_resnet = np.argmax(preds_resnet, axis=-1)
                pred_class_vgg = np.argmax(preds_vgg, axis=-1)
                pred_class_cnn = np.argmax(preds_cnn, axis=-1)
                class_labels = ["It's an Airplane", "It's a Car", "It's a Ship"]
                result_resnet = class_labels[pred_class_resnet[0]]
                result_vgg = class_labels[pred_class_vgg[0]]
                result_cnn = class_labels[pred_class_cnn[0]]

                # Return results in three lines
                return f"ResNet50 Prediction: {result_resnet}\nVGG16 Prediction: {result_vgg}\nCustom CNN Prediction: {result_cnn}"
            else:
                return "No file uploaded", 400
    except Exception as e:
        # Log the error
            print(f"Error occurred: {e}", file=sys.stderr)
            return "An error occurred", 500

if __name__ == '__main__':
    app.run(debug=True)
